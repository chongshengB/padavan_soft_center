#!/bin/sh
#===================================================================
#chongshengB 20200319
export PATH='/jffs/pdvsoft/bin:/usr/bin:/usr/sbin:/sbin:/bin'

start_link() {
rm -rf /tmp/dlist.txt
logger -t "SS" "开始运行订阅脚本...请稍后..."
z=0
	online_url_nu=`dbus get ssconf_user_ss_dlink|base64_decode|sed 's/$/\n/'|sed '/^$/d'|wc -l`
	until [ "$z" == "$online_url_nu" ]
	do
		z=$(($z+1))
		url=`dbus get ssconf_user_ss_dlink|base64_decode|awk '{print $1}'|sed -n "$z p"|sed '/^#/d'`
		[ -z "$url" ] && continue
		echo $url >> /tmp/dlist.txt
		done
dbus list ssconf_basic_json | cut -d '_' -f 4 | cut -d '=' -f 1 > /tmp/dlinkold.txt
lua /jffs/pdvsoft/ss/dlink.lua
}

reset_link() {
	confs=`dbus list ssconf_basic_ | cut -d "=" -f 1`
	logger -t "SS" "关闭ShadowSocksR Plus+..."
	/jffs/pdvsoft/scripts/shadowsocks.sh stop 
	logger -t "SS" "正在删除订阅节点..."
	for conf in $confs
	do
		dbus remove $conf
	done
dbus set ssconf_user_ss_enable=0
dbus set ssconf_user_global_server="nil"
dbus set ssconf_user_udp_relay_server="nil"
	logger -t "SS" "已重置订阅节点文件,请手动刷新页面..."
}

update_link() {
logger -t "SS" "开始更新订阅脚本..."
grep -v '^#' /etc/storage/ss_dlink.sh | grep -v "^$" > /tmp/dlist.txt
dbus list ssconf_basic_json | cut -d '_' -f 4 | cut -d '=' -f 1 > /tmp/dlinkold.txt
lua /etc_ro/ss/dlink.lua
}

case $1 in
start)
	start_link
	;;
reset)
	reset_link
	;;
update)
	update_link
	;;
*) 
    ;;

esac
