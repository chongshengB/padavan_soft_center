#!/bin/sh
/jffs/pdvsoft/scripts/shadowsocks.sh stop
logger -t "SS" "删除数据"
dbus remove ssconf_user_ss_enable
dbus remove ssconf_user_global_server
dbus remove ssconf_user_udp_relay_server
dbus remove ssconf_user_ss_threads
dbus remove ssconf_user_ss_run_mode
dbus remove ssconf_user_pdnsd_enable
dbus remove ssconf_user_s_dports
dbus remove ssconf_user_ssp_local_port
dbus remove ssconf_user_china_dns
dbus remove ssconf_user_tunnel_forward
dbus remove ssconf_user_lan_con
dbus remove ssconf_user_ss_chdns
dbus remove ssconf_user_socks5_enable
dbus remove ssconf_user_socks5_wenable
dbus remove ssconf_user_socks5_port
dbus remove ssconf_user_socks5_aenable
dbus remove ssconf_user_socks5_s_username
dbus remove ssconf_user_socks5_s_password
dbus remove ssconf_user_ss_watchcat
dbus remove ssconf_user_ss_turn_s
dbus remove ssconf_user_ss_turn_ss
dbus remove ssconf_user_ss_adblock
dbus remove ssconf_user_ss_adblock_url
dbus remove ssconf_user_ss_chnroute_url
dbus remove ssconf_user_ss_update_chnroute
dbus remove ssconf_user_ss_update_gfwlist
dbus remove ssconf_user_ss_dlink
dbus remove shadowsocks_install
dbus remove pdvsoft_app_shadowsocks
confs=`dbus list ssconf_basic_ | cut -d "=" -f 1`
logger -t "SS" "正在删除节点..."
for conf in $confs
do
dbus remove $conf
done
logger -t "SS" "删除jffs分区文件"
rm -rf /jffs/pdvsoft/scripts/shadowsocks.sh
rm -rf /jffs/pdvsoft/scripts/allping.sh
rm -rf /jffs/pdvsoft/scripts/ping.sh
rm -rf /jffs/pdvsoft/scripts/update_chnroute.sh
rm -rf /jffs/pdvsoft/scripts/update_dlink.sh
rm -rf /jffs/pdvsoft/scripts/update_gfwlist.sh
rm -rf /jffs/pdvsoft/webs/shadowsocks.asp
rm -rf /jffs/pdvsoft/bin/chinadns-ng
rm -rf /jffs/pdvsoft/bin/dns2tcp
rm -rf /jffs/pdvsoft/bin/ipt2socks
rm -rf /jffs/pdvsoft/bin/pdnsd
rm -rf /jffs/pdvsoft/bin/ss-check
rm -rf /jffs/pdvsoft/bin/ss-redir
rm -rf /jffs/pdvsoft/bin/ssr-monitor
rm -rf /jffs/pdvsoft/bin/ssr-redir
rm -rf /jffs/pdvsoft/bin/ssr-switch
rm -rf /jffs/pdvsoft/bin/ss-rules
rm -rf /jffs/pdvsoft/ss
logger -t "SS" "已完成"



