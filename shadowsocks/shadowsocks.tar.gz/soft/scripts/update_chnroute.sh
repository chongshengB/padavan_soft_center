#!/bin/sh

set -e -o pipefail

[ "$1" != "force" ] && [ "$(dbus get ssconf_user_ss_update_chnroute)" != "1" ] && exit 0
CHNROUTE_URL="$(dbus get ssconf_user_ss_chnroute_url)"

logger -st "chnroute" "Starting update..."
rm -f /tmp/chinadns_chnroute.txt

if [ -z "$CHNROUTE_URL" ]; then
	curl -k -s --connect-timeout 20 --retry 3 http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest | \
		awk -F\| '/CN\|ipv4/ { printf("%s/%d\n", $4, 32-log($5)/log(2)) }' > /tmp/chinadns_chnroute.txt
else
	curl -k -s --connect-timeout 20 --retry 3 -o /tmp/chinadns_chnroute.txt "$CHNROUTE_URL"
fi

[ ! -d /jffs/pdvsoft/ss/rules/ ] && mkdir /jffs/pdvsoft/ss/rules/
mv -f /tmp/chinadns_chnroute.txt /jffs/pdvsoft/ss/rules/chnroute.txt


[ -f /jffs/pdvsoft/scripts/shadowsocks.sh ] && [ "$(dbus get ssconf_user_ss_enable)" = "1" ] && [ "$(dbus get ssconf_user_ss_run_mode)" = "router" ] && /jffs/pdvsoft/scripts/shadowsocks.sh restart >/dev/null 2>&1

logger -st "chnroute" "Update done"
