#!/bin/sh

set -e -o pipefail
[ "$1" != "force" ] && [ "$(dbus get ssconf_user_ss_update_gfwlist)" != "1" ] && exit 0
#GFWLIST_URL="$(nvram get gfwlist_url)"
logger -st "gfwlist" "Starting update..."
curl -k -s -o /tmp/gfwlist_list.conf --connect-timeout 15 --retry 5 https://cokebar.github.io/gfwlist2dnsmasq/gfwlist_domain.txt
count=`awk '{print NR}' /tmp/gfwlist_list.conf|tail -n1`
if [ $count -gt 1000 ]; then
rm -f /jffs/pdvsoft/ss/rules/gfwlist_list.conf
logger -st "gfwlist" "正在处理gfwlist文件..."
awk '{printf("server=/%s/127.0.0.1#5353\nipset=/%s/gfwlist\n", $1, $1 )}' /tmp/gfwlist_list.conf > /jffs/pdvsoft/ss/rules/gfwlist_list.conf

logger -st "gfwlist" "Update done"
[ -f /jffs/pdvsoft/scripts/shadowsocks.sh ] && [ "$(dbus get ssconf_user_ss_enable)" = "1" ] && [ "$(dbus get ssconf_user_ss_run_mode)" = "gfw" ] && /jffs/pdvsoft/scripts/shadowsocks.sh restart >/dev/null 2>&1
else
logger -st "gfwlist" "列表下载失败,请重试！"
fi
rm -f /tmp/gfwlist_list.conf