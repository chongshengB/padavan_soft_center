#!/bin/sh
if [ ! -f "/jffs/pdvsoft/scripts/shadowsocks.sh" ];then
logger -t "SS" "生成默认配置数据"
dbus set ssconf_user_ss_enable=0
dbus set ssconf_user_global_server="nil"
dbus set ssconf_user_udp_relay_server="nil"
dbus set ssconf_user_ss_threads=0
dbus set ssconf_user_ss_run_mode="gfw"
dbus set ssconf_user_pdnsd_enable=0
dbus set ssconf_user_s_dports=0
dbus set ssconf_user_ssp_local_port=1080
dbus set ssconf_user_china_dns="223.5.5.5#53"
dbus set ssconf_user_tunnel_forward="8.8.8.8#53"
dbus set ssconf_user_lan_con=0
dbus set ssconf_user_ss_chdns=0
dbus set ssconf_user_socks5_enable=0
dbus set ssconf_user_socks5_wenable=0
dbus set ssconf_user_socks5_port=1088
dbus set ssconf_user_socks5_aenable=0
dbus set ssconf_user_socks5_s_username=""
dbus set ssconf_user_socks5_s_password=""
dbus set ssconf_user_ss_watchcat=0
dbus set ssconf_user_ss_turn_s=600
dbus set ssconf_user_ss_turn_ss=5
dbus set ssconf_user_ss_adblock=0
dbus set ssconf_user_ss_adblock_url="https://gitee.com/privacy-protection-tools/anti-ad/raw/master/anti-ad-for-dnsmasq.conf"
dbus set ssconf_user_ss_chnroute_url="https://ispip.clang.cn/all_cn.txt"
dbus set ssconf_user_ss_update_chnroute=0
dbus set ssconf_user_ss_update_gfwlist=0
else
/jffs/pdvsoft/scripts/shadowsocks.sh stop
fi
logger -t "SS" "复制文件到jffs分区"
cp -rf /tmp/soft/webs /jffs/pdvsoft/
cp -rf /tmp/soft/scripts /jffs/pdvsoft/
cp -rf /tmp/soft/bin /jffs/pdvsoft/
cp -rf /tmp/soft/ss /jffs/pdvsoft/
ln -sf /jffs/pdvsoft/scripts/shadowsocks.sh /jffs/pdvsoft/init.d/s9_shadowsocks.sh
dbus set pdvsoft_app_shadowsocks='{"name":"科学上网","version":"1.1","webpage":"shadowsocks.asp"}'
logger -t "SS" "已完成"



